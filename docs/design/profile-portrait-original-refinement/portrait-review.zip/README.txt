Open index.html to review the matched desktop and phone screenshots offline.
This is a static comparison package, not a video or a running application.
Use the refinement draft PR stacked above #34 for the exact Vercel Preview URL.
Review branch URL: See the refinement draft PR
First verified Preview: See the refinement draft PR
Interactive path: /review/profile-portrait
Hosted comparison: /review/portrait-comparison/index.html
Sign in with an authorized Vercel account if deployment protection requires it.
The production domain and /profile retain the accepted portrait.
Master: untouched 1000689121.jpg. Edited crop: 960x1696; tone curve + alpha only.
Backpack retained; convincing clothing-only retouching remains outstanding.
Speaking/gesturing production remains outstanding; see video-production.md.
