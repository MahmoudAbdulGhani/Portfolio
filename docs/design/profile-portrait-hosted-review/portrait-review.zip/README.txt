Open index.html to review the matched desktop and phone screenshots offline.
This is a static comparison package, not a video or a running application.
Use the new draft PR based on prototype/profile-standing-portrait for the exact Vercel Preview URL.
Review branch URL: https://mahmoud-portfolio-git-pro-ded3c7-mahmoud-abdul-ghani-s-projects.vercel.app
First verified Preview: https://mahmoud-portfolio-bljw2ctks-mahmoud-abdul-ghani-s-projects.vercel.app
Interactive path: /review/profile-portrait
Hosted comparison: /review/portrait-comparison/index.html
Sign in with an authorized Vercel account if deployment protection requires it.
The production domain and /profile retain the accepted portrait.
The source crop is 326x1027 pixels. Enlarging its display adds no authentic detail.
Speaking/gesturing production remains outstanding; see video-production.md.
