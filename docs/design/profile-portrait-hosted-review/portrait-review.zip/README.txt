Open index.html to review the matched desktop and phone screenshots offline.
This is a static comparison package, not a video or a running application.
Use the new draft PR based on prototype/profile-standing-portrait for the exact Vercel Preview URL.
Interactive path: /review/profile-portrait
Hosted comparison: /review/portrait-comparison/index.html
Sign in with an authorized Vercel account if deployment protection requires it.
The production domain and /profile retain the accepted portrait.
The source crop is 326x1027 pixels. Enlarging its display adds no authentic detail.
Speaking/gesturing production remains outstanding; see video-production.md.
