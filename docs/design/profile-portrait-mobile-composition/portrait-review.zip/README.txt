Open index.html to review the matched desktop and phone screenshots offline.
This is a static comparison package, not a video or a running application.
Use the mobile composition draft PR stacked above #35 for the exact Vercel Preview URL.
Review branch URL: See the refinement draft PR
First verified Preview: See the refinement draft PR
Interactive path: /review/profile-portrait
Hosted comparison: /review/portrait-comparison/index.html
Sign in with an authorized Vercel account if deployment protection requires it.
The production domain and /profile retain the accepted portrait.
Before: PR #35, commit 376584bbc8297b2e0afaa8a80a36d69df3591af2.
The existing 960x1696 portrait and processing are unchanged.
Backpack retained. Speaking/gesturing production remains separate.
