Extract this package and open index.html. No server or Vercel sign-in is needed.
Before: normal /profile at PR #37, commit 5db900a204c5f475f6906bd28d05913227f8a8f5.
After: the approved PR #37 composition adopted into the normal /profile route.
Use /profile on the adoption draft PR Preview for interaction checks.
The exact Preview URL and deployment commit are recorded on that draft PR.
Authorized Vercel sign-in may be required; deployment protection is unchanged.
No promotion, merge or manual deployment was performed.
Normal builds contain the approved portrait but exclude review routes/comparison assets.
The approved PNG/WebP and original processing are unchanged; backpack retained.
Speaking/gesturing video remains unfinished and separate.
Windows Chrome emulation, not physical-device verification.
